import logo from './logo.svg';
import './App.css';
import OurProducts from './Components/OurProducts';
import Footer from './Components/Footer';
import AboutUs from './Components/AboutUs';
import Deals from './Components/Deals';
import Gallery from './Components/Gallery';
import Login from './Components/Login';
import Signup from './Components/Signup';
import HomePage from './Components/HomePage';
import Collection from './Components/Collection';
import SubCategories from './Components/Utilities/SubCategories';
import Tshirts from './Components/Utilities/Tshirts';

function App() {
  return (
//<Collection/>
      <HomePage/>
//<Tshirts/>
    //<Signup/>
    //  <Login/>
    //<OurProducts/>
  //<AboutUs/>
   //<Footer/>
   //<Deals/>
   //<Gallery/>
   );
}

export default App;
